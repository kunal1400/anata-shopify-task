const { request } = require('graphql-request');

// configuration
const adminAPIToken = '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';
const storefrontAPIToken = '700c88fcf8f4e9329316e9c154258266';
const shopDomain= 'green-check-1183';

// const adminAPIToken = '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';
// const storefrontAPIToken = '48a0695d94b0b64f37f038325558563d';
// const shopDomain= 'kunal1400';


const shopifyGraphQLEndpoint = `https://${shopDomain}.myshopify.com/api/2024-04/graphql.json`;

const getProductsWithVariantsQuery = `
  query GetProductsWithVariants($name: String!) {
    products(first: 10, query: $name) {
      edges {
        node {
          title
          variants(first: 10) {
            edges {
              node {
                title
                priceV2 {
                  amount
                  currencyCode
                }
              }
            }
          }
        }
      }
    }
  }
`;

async function fetchProductsByName(name) {
  try {
    const data = await request(shopifyGraphQLEndpoint, getProductsWithVariantsQuery, {
      name: `${name}`,
    }, {
        'X-Shopify-Storefront-Access-Token': storefrontAPIToken,
        // 'Content-Type': 'application/json',
        // 'X-Shopify-Admin-Access-Token': adminAPIToken,
        // 'X-Shopify-Access-Token': adminAPIToken,
        });

    const products = data.products.edges;

    products.forEach((product) => {
      console.log(`Product: ${product.node.title}`);
      product.node.variants.edges.sort((a, b) => a.node.priceV2.amount - b.node.priceV2.amount);
      product.node.variants.edges.forEach((variant) => {
        console.log(`- Variant: ${variant.node.title} - Price: ${variant.node.priceV2.amount} ${variant.node.priceV2.currencyCode}`);
      });
    });
  } catch (error) {
    console.error('Error fetching products:', error);
  }
}

const args = process.argv.slice(2);
if (args.length !== 2 || args[0] !== '-name') {
  console.error('Usage: node app.js -name <product_name>');
  process.exit(1);
}


const productName = args[1];
fetchProductsByName(productName);
